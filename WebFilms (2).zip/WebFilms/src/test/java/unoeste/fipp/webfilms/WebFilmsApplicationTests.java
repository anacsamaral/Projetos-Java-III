package unoeste.fipp.webfilms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebFilmsApplicationTests {

    @Test
    void contextLoads() {
    }

}
