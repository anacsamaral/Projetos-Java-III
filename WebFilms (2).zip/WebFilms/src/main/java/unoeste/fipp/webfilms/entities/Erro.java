package unoeste.fipp.webfilms.entities;

public record Erro(String message, String description) {
}
