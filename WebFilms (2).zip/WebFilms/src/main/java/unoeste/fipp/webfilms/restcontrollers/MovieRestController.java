package unoeste.fipp.webfilms.restcontrollers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import unoeste.fipp.webfilms.entities.Erro;
import unoeste.fipp.webfilms.entities.Movie;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("apis")
public class MovieRestController {

    @GetMapping("test")
    ResponseEntity<Object> test(){
        return ResponseEntity.ok().build();
    }

    @GetMapping("random-movie")
    public ResponseEntity<Object> randomMovie() {
        Movie aux = getMovies().get((int)(Math.random() * getMovies().size()));
        return ResponseEntity.ok().body(aux);
    }

    @GetMapping("get-movie")
    public ResponseEntity<Object> getMovieTitle(String titulo) {
        Movie aux = null;
        for(Movie mov : getMovies()) {
            if(mov.getTitle().equalsIgnoreCase(titulo))
                aux = mov;
        }
        if(aux != null)
            return ResponseEntity.ok().body(aux);
        else
            return ResponseEntity.badRequest().body(new Erro("Filme não encontrado",""));
        // não pode retornar uma string pois é esperado um JSON
        // ou retorna dentro do objeto movie, ou crie um objeto que represente erros (mais indicado)
    }

    public List<Movie> getMovies() {
        List<Movie> movies = new ArrayList<>();

        movies.add(new Movie("Cidadão Kane", "1941", "Drama"));
        movies.add(new Movie("Casablanca", "1942", "Romance"));
        movies.add(new Movie("O Poderoso Chefão", "1972", "Crime"));
        movies.add(new Movie("Os Sete Samurais", "1954", "Ação"));
        movies.add(new Movie("A Noviça Rebelde", "1965", "Musical"));
        movies.add(new Movie("Psicose", "1960", "Terror"));
        movies.add(new Movie("2001: Uma Odisseia no Espaço", "1968", "Ficção Científica"));
        movies.add(new Movie("A Felicidade Não Se Compra", "1946", "Drama"));
        movies.add(new Movie("O Mágico de Oz", "1939", "Fantasia"));
        movies.add(new Movie("Laranja Mecânica", "1971", "Ficção Científica"));
        movies.add(new Movie("Taxi Driver", "1976", "Drama"));
        movies.add(new Movie("O Exorcista", "1973", "Terror"));
        movies.add(new Movie("A Lista de Schindler", "1993", "Drama"));
        movies.add(new Movie("O Silêncio dos Inocentes", "1991", "Thriller"));
        movies.add(new Movie("Doutor Jivago", "1965", "Drama"));
        movies.add(new Movie("Sangue Negro", "2007", "Drama"));
        movies.add(new Movie("O Grande Lebowski", "1998", "Comédia"));
        movies.add(new Movie("Forrest Gump", "1994", "Drama"));
        movies.add(new Movie("Caminhos Perigosos", "1953", "Crime"));
        movies.add(new Movie("Encontros e Desencontros", "2003", "Comédia Romance"));

        return movies;
    }
}
