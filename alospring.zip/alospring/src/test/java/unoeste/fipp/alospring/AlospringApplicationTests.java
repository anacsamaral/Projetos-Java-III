package unoeste.fipp.alospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlospringApplicationTests {

	@Test
	void contextLoads() {
	}

}
