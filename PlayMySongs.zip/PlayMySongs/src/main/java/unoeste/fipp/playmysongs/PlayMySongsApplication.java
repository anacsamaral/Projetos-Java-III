package unoeste.fipp.playmysongs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayMySongsApplication {
    public static void main(String[] args) {
        SpringApplication.run(PlayMySongsApplication.class, args);
    }
}
